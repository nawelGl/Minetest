minetest.register_chatcommand("returnpos", {
    func = function(name, param)
        if param == "" then
            return false, "Nom de joueur requis."
        end

        local player = minetest.get_player_by_name(param)

        if not player then
            return false, "il n'y a pas de joueur avec ce nom."
        end

        local pos = player:get_pos()
        local coordinatesForPlayer = "%s est en X = %.2f, Y = %.2f, Z = %.2f"
        local playerPos = coordinatesForPlayer:format(param, pos.x, pos.y, pos.z)
        
        local currentWorldPath = minetest.get_worldpath()
        minetest.safe_file_write(currentWorldPath.."/player_positions.lua", playerPos)

        return true, playerPos
    end,
})

--[[
Je dois savoir combien de joueurs il y a, ainsi que leur nom.
Je vais ensuite faire une boucle qui va ajouter, ligne par ligne, le nom et chaque coordonnée à une variable.
Finalement, je vais écrire cette variable (string) dans un fichier.
        --]]

minetest.register_chatcommand("returnposall", {
    func = function(name, param)
        local playerList = minetest.get_connected_players()

        local count = 1
        for _ in pairs(playerList) do
            local playerName = playerList[count]:get_player_name()
            local player = minetest.get_player_by_name(playerName)

            local pos = player:get_pos()
            local coordinatesForPlayer = "%s est en X = %.2f, Y = %.2f, Z = %.2f"
            local playerPos = coordinatesForPlayer:format(playerName, pos.x, pos.y, pos.z)
            minetest.log(playerPos)

            local databaseLine = ""

            count = count + 1
        end

        return true
    end,
    })