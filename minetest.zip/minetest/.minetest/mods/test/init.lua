minetest.register_chatcommand("foo", {
    privs = {
        interact = true,
    },
    func = function(name, param)
        return true, "You said " .. param .. "!"
    end,
})

--https://github.com/minetest/minetest/blob/master/doc/lua_api.md
--https://rubenwardy.com/minetest_modding_book/en/players/chat.html
--https://github.com/minetest/minetest/blob/master/doc/lua_api.txt