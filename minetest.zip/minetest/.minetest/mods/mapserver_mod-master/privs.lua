
minetest.register_privilege("mapserver_hide_player", {
	description = "Player is hidden from the map",
	give_to_singleplayer = false
})
